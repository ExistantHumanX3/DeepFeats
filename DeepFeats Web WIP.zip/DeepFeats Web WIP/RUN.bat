echo Server Starting
echo IP: localhost:8000
python -m http.server
